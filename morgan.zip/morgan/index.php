<?php get_header( );?>
        
      
        <?php get_template_part( 'template-part/hero');?>
        <?php get_template_part( 'template-part/about');?>
        <?php get_template_part( 'template-part/services');?>
        <?php get_template_part( 'template-part/portfolio');?>
        <?php get_template_part( 'template-part/contact');?>
      

<?php get_footer( );?>


    